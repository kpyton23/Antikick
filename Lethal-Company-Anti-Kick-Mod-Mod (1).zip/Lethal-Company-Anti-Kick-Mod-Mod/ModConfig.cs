﻿using BepInEx.Configuration;

namespace Lethal_Company_Mod
{
    public class ModConfig
    {
        public static ConfigEntry<bool> EnableAntiKick;
    }
}
