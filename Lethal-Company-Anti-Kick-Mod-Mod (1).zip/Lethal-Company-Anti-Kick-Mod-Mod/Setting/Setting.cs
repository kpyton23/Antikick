public static class Setting 
{
    public static bool EnableAntiKick { get; set; } = true;
}
