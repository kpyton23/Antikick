<p align="center">
      <img src="https://i.ibb.co/5YrsZ2T/1.png" width="657">
</p>

## About

This mod add funtction Anti KIck

## Developers

- [Lemon4ik] ([GitHub Profile Link](https://github.com/Lemon4ik666)https://github.com/Lemon4ik666)
